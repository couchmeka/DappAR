# SensorIo
Ardinuo uno Sensor reading values
