#!/usr/bin/env python3
from flask import Flask,render_template
import pyfirmata
from flask_socketio import SocketIO,emit,disconnect
from flask_login import current_user,LoginManager
import eventlet
import time
import functools

async_mode = 'eventlet'
eventlet.monkey_patch()
app = Flask(__name__)
login_manager = LoginManager()
socketio = SocketIO(app, async_mode=async_mode)


@app.route('/')
def index():
    return render_template("index.html")
def authenticated_only(f):
    @functools.wraps(f)
    def wrapped(*args, **kwargs):
        if not current_user.is_authenticated:
            disconnect()
        else:
            return f(*args, **kwargs)
    return wrapped

@socketio.on('connect')
def connect_handler():
    if current_user.is_authenticated:
        emit('my response',
             {'message': '{0} has joined'.format(current_user.name)},
             broadcast=True)
    else:
        return False  # not allowed here

@socketio.event
@authenticated_only
def my_event(message):
    
    board = pyfirmata.Arduino('/dev/ttyACM0')
    it = pyfirmata.util.Iterator(board)
    it.start()

    analog_input = board.get_pin('a:0:i')
    analog_value=None
    while True:
        analog_value = analog_input.read()
        print(analog_value)
        time.sleep(0.1)
        emit('my response', {'data':analog_value})
    
    
if __name__ == '__main__':
    login_manager.init_app(app)
    socketio.run(app,debug=True)